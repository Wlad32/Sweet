CREATE DATABASE Sweet;

USE Sweet;
GO

CREATE TABLE Categories (
    CategoryID INT PRIMARY KEY,
    CategoryName VARCHAR(255) NOT NULL
);

CREATE TABLE Suppliers (
    SupplierID INT PRIMARY KEY,
    SupplierName VARCHAR(255) NOT NULL,
    ContactEmail VARCHAR(255),
    PhoneNumber VARCHAR(50)
);

CREATE TABLE Manufacturers (
    ManufacturerID INT PRIMARY KEY,
    ManufacturerName VARCHAR(255) NOT NULL,
    ContactEmail VARCHAR(255),
    PhoneNumber VARCHAR(50)
);

CREATE TABLE Products (
    ProductID INT PRIMARY KEY,
    ProductName VARCHAR(255) NOT NULL,
    Price MONEY CHECK (Price >= 0), 
    Quantity INT CHECK (Quantity >= 0), 
    ManufactureDate DATE,
    CategoryID INT,
    SupplierID INT,
    ManufacturerID INT,
    FOREIGN KEY (CategoryID) REFERENCES Categories(CategoryID),
    FOREIGN KEY (SupplierID) REFERENCES Suppliers(SupplierID),
    FOREIGN KEY (ManufacturerID) REFERENCES Manufacturers(ManufacturerID)
);

CREATE TABLE Customers (
    CustomerID INT PRIMARY KEY,
    CustomerName VARCHAR(255) NOT NULL,
    ContactEmail VARCHAR(255),
    PhoneNumber VARCHAR(50)
);

CREATE TABLE Sales (
    SaleID INT PRIMARY KEY,
    SaleDate DATE NOT NULL,
    ProductID INT,
    CustomerID INT, 
    Quantity INT CHECK (Quantity > 0), 
    FOREIGN KEY (ProductID) REFERENCES Products(ProductID),
    FOREIGN KEY (CustomerID) REFERENCES Customers(CustomerID)
);

CREATE TABLE Ingredients (
    IngredientID INT PRIMARY KEY,
    IngredientName VARCHAR(255) NOT NULL,
    Price MONEY CHECK (Price >= 0), 
    Quantity INT CHECK (Quantity >= 0) 
);

CREATE TABLE Recipes (
    RecipeID INT PRIMARY KEY,
    ProductID INT,
    IngredientID INT,
    IngredientQuantity INT CHECK (IngredientQuantity > 0), 
    FOREIGN KEY (ProductID) REFERENCES Products(ProductID),
    FOREIGN KEY (IngredientID) REFERENCES Ingredients(IngredientID)
);